import React from 'react'
import Sidebar from '../../components/sidebar/Sidebar'
const Home = () => {
  return (
    <div>
        <Sidebar />
    </div>
  )
}

export default Home